# DentalProject_Graduation
## Using Asp.net Core - AI - identity User - sql server - linq-entity framework core- html -css-bootsratp-jquery-ajax
## if you want an AI model and the way which we use to attach the python model with the .NET ,send me a message 
A system for diagnosing dental diseases for dental disease and their communication with doctors and dental students, Beni Suef University to treat them, follow up and coordinate appointments between the two parties through the system, and alert students while adding new diagnostic cases on the site by e-mail and follow-up on cases that he treats through his personal file as well The patient can view his personal data and know the dates of the sessions in the hospital and the doctors treating him

dental students, Beni Suef University to treat them, follow up and coordinate appointments between the two
parties through the system, and alert students while adding new diagnostic cases on the site by e-mail and follow-up
on cases that he treats through his personal file as well The patient can view his personal data and know the dates of
the sessions in the hospital and the doctors treating him.
"# Dentist_Faculty_System" 
"# Dentist_Faculty_System" 
