﻿namespace DentalProject_Graduation.Data.Entities
{
    public class ViladCases
    {
        public  int IdCases { set; get; }

        public int IdDiseas { set; get; }
        public string NameDiseas { set; get; }
        public byte[] photo { set; get; }
        }
    }

