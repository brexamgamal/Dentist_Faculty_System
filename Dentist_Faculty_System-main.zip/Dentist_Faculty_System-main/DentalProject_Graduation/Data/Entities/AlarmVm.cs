﻿using System.ComponentModel.DataAnnotations.Schema;

namespace DentalProject_Graduation.Data.Entities
{
    public class AlarmVm
    {
    
        public string IdDentail { get; set; }

      
        public int IdDiseaase { get; set; }
   
    }
}
