﻿namespace DentalProject_Graduation.Data.Entities
{
    public class CasesNotContactcs
    {
        public int CaseId { set; get; }
        public string DiseaseName { set; get; }
        public byte[]photo { set; get; }

    }
}
